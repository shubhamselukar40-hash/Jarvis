import datetime
from googleapiclient.discovery import build
from app.google_auth import get_credentials


def _service():
    creds = get_credentials()
    if not creds:
        raise RuntimeError("Google account not connected yet. Visit /auth/google first.")
    return build("calendar", "v3", credentials=creds)


def list_upcoming(max_results: int = 10, hours_ahead: int = 24):
    service = _service()
    now = datetime.datetime.utcnow().isoformat() + "Z"
    later = (
        datetime.datetime.utcnow() + datetime.timedelta(hours=hours_ahead)
    ).isoformat() + "Z"
    events_result = (
        service.events()
        .list(
            calendarId="primary",
            timeMin=now,
            timeMax=later,
            maxResults=max_results,
            singleEvents=True,
            orderBy="startTime",
        )
        .execute()
    )
    events = events_result.get("items", [])
    out = []
    for e in events:
        start = e["start"].get("dateTime", e["start"].get("date"))
        out.append({"summary": e.get("summary", "(no title)"), "start": start})
    return out


def create_event(summary: str, start_iso: str, end_iso: str, description: str = ""):
    """start_iso / end_iso like '2026-09-28T15:00:00+05:30'"""
    service = _service()
    event = {
        "summary": summary,
        "description": description,
        "start": {"dateTime": start_iso},
        "end": {"dateTime": end_iso},
    }
    created = service.events().insert(calendarId="primary", body=event).execute()
    return created.get("htmlLink")
