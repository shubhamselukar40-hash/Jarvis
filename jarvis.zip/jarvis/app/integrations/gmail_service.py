import base64
from googleapiclient.discovery import build
from app.google_auth import get_credentials


def _service():
    creds = get_credentials()
    if not creds:
        raise RuntimeError("Google account not connected yet. Visit /auth/google first.")
    return build("gmail", "v1", credentials=creds)


def _decode_snippet(msg) -> str:
    return msg.get("snippet", "")


def get_recent_unread(max_results: int = 8):
    """Returns a list of {from, subject, snippet} for recent unread mail."""
    service = _service()
    results = (
        service.users()
        .messages()
        .list(userId="me", labelIds=["INBOX", "UNREAD"], maxResults=max_results)
        .execute()
    )
    messages = results.get("messages", [])
    out = []
    for m in messages:
        full = (
            service.users()
            .messages()
            .get(userId="me", id=m["id"], format="metadata",
                 metadataHeaders=["From", "Subject"])
            .execute()
        )
        headers = {h["name"]: h["value"] for h in full["payload"]["headers"]}
        out.append(
            {
                "from": headers.get("From", "Unknown"),
                "subject": headers.get("Subject", "(no subject)"),
                "snippet": _decode_snippet(full),
            }
        )
    return out
