import os
from twilio.rest import Client

_client = None


def _get_client():
    global _client
    if _client is None:
        _client = Client(os.environ["TWILIO_ACCOUNT_SID"], os.environ["TWILIO_AUTH_TOKEN"])
    return _client


def send_whatsapp(body: str, to: str | None = None):
    """Send a proactive WhatsApp message (used by reminders/scheduler)."""
    to = to or os.environ["MY_WHATSAPP_NUMBER"]
    client = _get_client()
    client.messages.create(
        from_=os.environ["TWILIO_WHATSAPP_FROM"],
        to=to,
        body=body,
    )
